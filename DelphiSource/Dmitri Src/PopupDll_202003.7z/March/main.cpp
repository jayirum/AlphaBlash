//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;

typedef int (__stdcall *TCharFunction)(char* instr);
TCharFunction CharFunction;

typedef int (__stdcall *TWideCharFunction)(wchar_t* title, wchar_t* message);
TWideCharFunction WideCharFunction;

typedef void (__stdcall *TInitFunction)(void);
TInitFunction InitFunction;

typedef void (__stdcall *TShowFunction)(void);
TShowFunction ShowFunction;

typedef void (__stdcall *THideFunction)(void);
THideFunction HideFunction;

typedef int (__stdcall *TAddMessFunction)(wchar_t* title, wchar_t* message, int sound);
TAddMessFunction AddMessFunction;


//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------
void __fastcall TForm3::FormCreate(TObject *Sender)
{
	HMODULE myDLL = LoadLibraryA("DelphiDLL4CPPApp.dll");
	if (myDLL <= 0)
	{
		ShowMessage("DLL not found !");
		return;
	}
	CharFunction = NULL;
	//CharFunction = (TCharFunction)GetProcAddress(myDLL, "CharFunction");
	CharFunction = (TCharFunction)GetProcAddress(myDLL,"CharFunction");
	if (CharFunction == NULL)
	{
	  ShowMessage("CharFunction function not found in the DLL !");
	  return;
	}

	WideCharFunction = (TWideCharFunction)GetProcAddress(myDLL,"WideCharFunction");
	if (WideCharFunction == NULL)
	{
	  ShowMessage("WideCharFunction function not found in the DLL !");
	  return;
	}

	ShowFunction = (TInitFunction)GetProcAddress(myDLL,"ShowFunction");
	if (ShowFunction == NULL)
	{
	  ShowMessage("ShowFunction function not found in the DLL !");
	  return;
	}

	HideFunction = (TInitFunction)GetProcAddress(myDLL,"HideFunction");
	if (HideFunction == NULL)
	{
	  ShowMessage("HideFunction function not found in the DLL !");
	  return;
	}

	InitFunction = (TInitFunction)GetProcAddress(myDLL,"Initialize");
	if (InitFunction == NULL)
	{
	  ShowMessage("Initialize function not found in the DLL !");
	  return;
	}

	AddMessFunction = (TAddMessFunction)GetProcAddress(myDLL,"AddMessage");
	if (AddMessFunction == NULL)
	{
	  ShowMessage("AddMessage function not found in the DLL !");
	  return;
	}



}
//---------------------------------------------------------------------------
void __fastcall TForm3::Button1Click(TObject *Sender)
{
char* ttt;
UnicodeString w0 = "This is a title !";
UnicodeString w1 = "This is a message !";
int len = AddMessFunction(w0.c_str(), w1.c_str(), 0);
}
//---------------------------------------------------------------------------
void __fastcall TForm3::Button3Click(TObject *Sender)
{
InitFunction();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button4Click(TObject *Sender)
{
ShowFunction();
}
//---------------------------------------------------------------------------

